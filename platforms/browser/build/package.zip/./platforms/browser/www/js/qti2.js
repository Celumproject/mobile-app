function prepareFrom2(testSession){

    var questions = new Array;
    var innerSlides = "";
    var ts = testSession.assessmentItem;

    if(!isArray(ts)){
        ts = [ts];
    }

    $.each(ts, function(i, e){
        console.log("e : " + e);
        console.log("e : " + JSON.stringify(e));

        var propositions = [];
        var qNum = parseInt(i) + 1;
        var qId = e._title.replace(" ", "_");
        var qTitle = e._title;
        var qType = e.responseDeclaration._cardinality;
        var qUrl = e._url;

        var qVideo = e._video;
        var qImage = e._image;

        qImage = "https://domoscio.com/wp-content/uploads/logo-domoscio.svg";


        var questionText = htmlDecode(e.itemBody.choiceInteraction.prompt);

        innerSlides += "<div class='swiper-slide'><div class='content-block-title color-blue'><center>" + qTitle + "</center></div>";
        innerSlides += "<div><span>" + questionText + "</span></div>";

        var full_image = "";
        //if (qImage != null){

        if (qNum == 1){
            innerSlides += "<center><a href='javascript:zoomImage();' data-num= '" + qNum + "' data-src='" + qImage + "'><div class='question-image'><img id='img_" + qNum + "' src='" + qImage + "'></img></div></a></center>";
            full_image += "<a href='javascript:dezoomImage();' class=''><div id='id_view_image_body_" + qNum + "'></div>";
            full_image += "<div id='id_view_image_" + qNum + "'></div></a>";
        }
        /*

        if (qNum == 1){
             innerSlides += "<center><a href='#' class='zoom-image'><div class='question-image'><img id='img_" + qNum + "' src='" + qImage + "'></img></div></a></center>";
             full_image += "<a href='javascript:dezoomImage();' class=''><div id='id_view_image_body_" + qNum + "'></div>";
             full_image += "<div id='id_view_image_" + qNum + "'></div></a>";
        }
         */

        //if (qVideo != null){
        if (qNum == 2){
            innerSlides += '<center><div><iframe width="320" height="177" src="https://www.youtube.com/embed/8MEZjrE7OKs" frameborder="0" allowfullscreen></iframe></div></center>';
        }


        innerSlides += "<form class='list-block inset' id='form_" + qId + "'><ul>";

        if(qType === "single"){
          innerSlides += "<li id='list_group_title_" + qNum + "' class='list-group-title'><div id='consigne_" + qId + "'> " + order_single + " </div></li>";
        } else {
          innerSlides += "<li class='list-group-title'> " + order_many + " </li>";
        }

        $.each(e.itemBody.choiceInteraction.simpleChoice, function(j, p){
            var prop_id = p._identifier;
            var prop_text = htmlDecode(p.__text);

            propositions.push(new Proposition(prop_id, prop_text));

            if(qType === "single"){
              innerSlides += "<li><label for='answer_" + qId + "_" + prop_id + "' class='label-radio item-content'>";
              innerSlides += "<input type='radio' name='radio_" + qId + "' id='answer_" + qId + "_" + prop_id + "' value=" + prop_id + "/><div class='item-media'><i class='icon icon-form-radio'></i></div><div class='item-inner' id='answer_content_" + qId + "_" + prop_id + "'><div>" + prop_text + "</div></div>";
              innerSlides += "</label></li>";
            } else {
              innerSlides += "<li><label for='answer_" + qId + "_" + prop_id + "' class='label-checkbox item-content'>";
              innerSlides += "<input type='checkbox' name='checkbox_" + qId + "' id='answer_" + qId + "_" + prop_id + "' value=" + prop_id + "/><div class='item-media'><i class='icon icon-form-checkbox'></i></div><div class='item-inner' id='answer_content_" + qId + "_" + prop_id + "'><div class='item-title'>" + prop_text + "</div></div>";
              innerSlides += "</label></li>";
            }
        });

        innerSlides += "</ul></form>";
        innerSlides += "<div id='block_" + qId + "' class='content-block'><div id='btn-q_" + qId + "' class='button ripple question_form'> " + answer_text + " </div></div>";
        innerSlides += full_image;
        innerSlides += "</div>";
        var qCorrect = [new Array(), new Array()];
        var tempProps = propositions;
/*
        $(".img_" + qNum).not(".no-fullscreen").click(function(){
            $("#id_view_image_" + qNum).html("<img src='"+$(this).attr('src')+"' class='view_image_img'/>");
            $("#id_view_image_body_" + qNum).addClass("view_image_body");
            $("#id_view_image_" + qNum).addClass("view_image");
        });

        $("#id_view_image_" + qNum).click(function(){
            $("#id_view_image_" + qNum).html("");
            $("#id_view_image_body_" + qNum).removeClass("view_image_body");
            $("#id_view_image_" + qNum).removeClass("view_image");
        });
*/
        $.each(e.responseDeclaration.correctResponse, function(k, c){
            qCorrect[0].push(c);
            tempProps.splice(tempProps.map(function(x) {return x.uid; }).indexOf(c), 1);
        });

        $.each(tempProps, function(k1,c1){
            qCorrect[1].push(c1);
        });

        questions.push(new Question(qNum, qId, qType, qTitle, qUrl, questionText, propositions, qCorrect));

    });

    return {
        questions: questions,
        innerSlides: innerSlides
    };
}
