var Question = function(qNum, qId, qType, qTitle, qUrl, qText, qProps, qCorrect){
    this.number = qNum;
    this.uid = qId;
    this.type = qType;
    this.text = qText;
    this.title = qTitle;
    this.url = qUrl;
    this.propositions = qProps;
    this.correctAnswers = qCorrect[0];
    this.wrongAnswers = qCorrect[1];

    this.correct = function(userInput){
        console.log(userInput, this.correctAnswers);
        var uid = this.uid;
        $.each(this.correctAnswers, function(i, a){
            $$("label[for=answer_" + uid + "_" + a + "]").addClass("bg-green color-white");
        });

        if (!findEqual(this.correctAnswers, userInput)) {
            $.each(userInput, function(i, ui){
                $$("label[for=answer_" + uid + "_" + ui + "]").addClass("bg-red color-white");
            });
            return false;
        } else {
            return true;
        }
    }
}

var Proposition = function(prop_id, prop_text){
    this.uid = prop_id;
    this.text = prop_text;
}




