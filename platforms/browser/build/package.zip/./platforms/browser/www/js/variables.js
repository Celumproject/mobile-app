// Initialize app
var myApp = new Framework7();
var $ = Framework7.$;



// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: true
});

// Identifiants de connexion à l'instance de l'API
var instance_id = 4;
var token = "7ea9eb050b16f560413ec539ad29dbba";

// Langue par défaut
var langue = "fr";
