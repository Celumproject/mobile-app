


function htmlDecode(input){
    var e = document.createElement('div');
    e.innerHTML = input;
    return e.childNodes.length === 0 ? "" : e.childNodes[0].nodeValue;
}

function findEqual(a, b) {
    var match = 0;
    for(var i=0;i<a.length;i++)
        for(var j=0;j<b.length;j++)
            if(b[j]===a[i])
            match++;

    if(match === a.length)
        return true;

    return false;
}

isArray = function(a) {
    return (!!a) && (a.constructor === Array);
}


function existsInArray(arr, thing){
    return arr.some(function(el){
        return el.url === thing;
    });
}


function afficheDate(d){
    return d[8] + d[9]+ '/' + d[5] + d[6] + '/' + d[0] + d[1] + d[2] + d[3];
}



function actualiserPageAccueil(){

    refresh_word();

    $$("#index-username").html(localStorage.getItem("firstname"));
    var nb_reviews=getNbReviews();

    $$("#index-nb-reviews").html(localStorage.getItem("nb_reviews"));
    var bouton_session = document.getElementById('go-test');
    if (nb_reviews===0){
        if (!bouton_session.classList.contains('disabled') ) {
            bouton_session.classList.add('disabled')
        }
        $$("#rappel-sg-pl").html( review_sg );
    }
    else {
        if (bouton_session.classList.contains('disabled') ) {
            bouton_session.classList.remove('disabled')
        }
        if (nb_reviews===1){
            $$("#rappel-sg-pl").html( review_sg );
        }
        else {
            $$("#rappel-sg-pl").html( review_pl );
        }
    }
}

function switchLanguage(){
    if (langue==="fr"){
        langue="en";
    }
    else {
        langue="fr";
    }
    actualiserPageAccueil();
}

function zoomImage(){
    console.log(MyApp.swiper.activeIndex);
    //Retrouver les data !!!
    var qNum = 1;
    var src = "https://domoscio.com/wp-content/uploads/logo-domoscio.svg";
    $("#id_view_image_" + qNum).html("<img src='"+ src +"' class='view_image_img'></img>");
    $("#id_view_image_body_" + qNum).addClass("view_image_body");
    $("#id_view_image_" + qNum).addClass("view_image");
    $("#list_group_title_" + qNum).removeClass("list-group-title");
}

function dezoomImage(){
    //Retrouver les data !!!

    qNum = 1;
    $("#id_view_image_" + qNum).html("");
    $("#id_view_image_body_" + qNum).removeClass("view_image_body");
    $("#id_view_image_" + qNum).removeClass("view_image");
    $("#list_group_title_" + qNum).addClass("list-group-title");
}
