// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {

    myApp.showPreloader(wait);


    console.log("Device is ready!");

    refresh_word();
    var device = myApp.device;
    if (device.ios) {
        $$("head").append($$("<link rel='stylesheet' href='lib/framework7/css/framework7.ios.min.css' type='text/css' />"));
        $$("head").append($$("<link rel='stylesheet' href='lib/framework7/css/framework7.ios.colors.min.css' type='text/css' />"));
    } else {
        $$("head").append($$("<link rel='stylesheet' href='lib/framework7/css/framework7.material.min.css' type='text/css' />"));
        $$("head").append($$("<link rel='stylesheet' href='lib/framework7/css/framework7.material.colors.min.css' type='text/css' />"));
    }

    if (device.android) {
          // Initialize Firebase
          var config = {
            apiKey: "AIzaSyAgKD-NEb9-ZOb8-ldN1eW2Ribz_hPkLY0",
            authDomain: "domoscio-app-test.firebaseapp.com",
            databaseURL: "https://domoscio-app-test.firebaseio.com",
            projectId: "domoscio-app-test",
            storageBucket: "domoscio-app-test.appspot.com",
            messagingSenderId: "451752671060"
          };
          firebase.initializeApp(config);
    }
    
    $$("head").append($$("<link rel='stylesheet' href='css/styles.css' type='text/css' />"));
    setTimeout(function() {
        navigator.splashscreen.hide();
    }, 4000);
    mainView.hideNavbar();

    var push = PushNotification.init({
        "android": {
            "senderID":"451752671060"
        },
        "browser": {pushServiceURL: 'http://push.api.phonegap.com/v1/push'},
        "ios": {
            "sound": true,
            "vibration": true,
            "badge": true
        },
        "windows": {}
    });

    push.on('registration', function(data) {
        console.log('registration event: ' + data.registrationId);

        var oldRegId = localStorage.getItem('registrationId');
        if (oldRegId !== data.registrationId) {
            // Save new registration ID
            localStorage.setItem("registrationId", data.registrationId);
            // Post registrationId to your app server as the value has changed
        }

        var parentElement = document.getElementById('registration');
        var listeningElement = parentElement.querySelector('.waiting');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');
    });

    push.on('error', function(e) {
        console.log("push error = " + e.message);
    });

    push.on('notification', function(data) {
        console.log('notification event');
        navigator.notification.alert(
            data.message,         // message
            null,                 // callback
            data.title,           // title
            'Ok'                  // buttonName
        );
    });

    myApp.hidePreloader();


});

myApp.onPageInit('index', function(page){
    mainView.hideNavbar();
});

myApp.onPageAfterAnimation('index', function(page){
    loginUser(localStorage.getItem("loginData"));
});

myApp.onPageBeforeAnimation('session', function(page){
    mainView.showNavbar();
    $$("#testsession").html(testsession);
    $$("#stop").html(stop);
    myApp.showPreloader(wait);
    parser = new DOMParser();

    //var answered = JSON.parse(localStorage.getItem("answeredQuestions"));
    //console.log(JSON.stringify(answered));

    var urls = getListeUrlQuestion();

    localStorage.setItem("testSession", "");
    var count = 0;
    $.each(urls, function(i, url){
        // Retrieve tests
        $.ajax({
            method: "GET",
            url: url,
            dataType: "xml",
            complete: function(e){
                if(e.responseText !== "null"){
                    console.log(e);
                    var temp = localStorage.getItem("testSession");
                    var q = e.responseText.replace('<?xml version="1.0" encoding="utf-8"?>', "").replace('schemaLocation="http://www.imsglobal.org/xsd/imsqti_v2p2 http://www.imsglobal.org/xsd/qti/qtiv2p2/imsqti_v2p2.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.imsglobal.org/xsd/imsqti_v2p2"', 'url="' + url.replace("http://quiz-beta.xperteam.net/webservices/quizmanagerwebservice.asmx/GetQuestion?pQuestionId=", "").replace("&pFormat=qti", "") + '"');

                    localStorage.setItem("testSession", temp + q);
                    count++;
                }

                if(count == (urls.length)){
                    var test = '<?xml version="1.0" encoding="utf-8"?><questestinterop title="TestSession">' + localStorage.getItem("testSession") + "</questestinterop>";
                    var xml2json = new X2JS();
                    console.log(test);
                    var testSessionJson = xml2json.xml_str2json(test);
                    prepareTestSession(testSessionJson);

                    myApp.hidePreloader();
                }
            }
        });
    });

});

myApp.onPageBeforeAnimation('*', function(page){
    if(page.name == "index"){
        mainView.hideNavbar();
        //console.log(localStorage.getItem('userData'));
    }
});

myApp.onPageBeforeAnimation('session_results', function(page){
    var rightAnswers = localStorage.getItem('rightAnswers');
    var wrongAnswers = localStorage.getItem('wrongAnswers');
    var skipped = parseInt(localStorage.getItem('totalAnswers')) - rightAnswers - wrongAnswers;
    var summary = localStorage.getItem('summary');

    $$("#total_right").html(rightAnswers);
    $$("#total_wrong").html(wrongAnswers);
    $$("#total_skipped").html(skipped);
    $$("#summary-list").html(summary);

    $$("#inshort").html(inshort);
    $$("#details").html(details);
    $$("#home").html(home);
});

myApp.onPageBack('session', function(page){
    console.log("back");
    localStorage.removeItem("testSession");
    $$(".swiper-wrapper").html('');
});

$$('#login-form .form-to-data').on('click', function(){
    var formData = myApp.formToData('#login-form');
    loginUser(formData);
});

$$('.open-login-screen').on('click', function(){
    localStorage.clear();
});

/*
$$('.zoom-image').on('click', function(){
    var qNum=1;
    console.log("On a au -------------------- essayé");
    $("#id_view_image_" + qNum).html("<img src='"+$(this).attr('src')+"' class='view_image_img'/>");
    $("#id_view_image_body_" + qNum).addClass("view_image_body");
    $("#id_view_image_" + qNum).addClass("view_image");
});

$("#id_view_image_" + qNum).click(function(){
    $("#id_view_image_" + qNum).html("");
    $("#id_view_image_body_" + qNum).removeClass("view_image_body");
    $("#id_view_image_" + qNum).removeClass("view_image");
});
*/
