var login;
var email;
var password;
var wrong_ids;
var welcome;
var youhave;
var review_sg;
var review_pl;
var logout;
var testsession;
var stop;
var order_single;
var order_many;
var answer_text;
var wait;
var inshort;
var details;
var home;
var swip_indication;
var flag;

function refresh_word(){
    if (langue==="fr"){
        login = "Se connecter";
        email = "Email";
        password = "Mot de passe";
        wrong_ids = "Mauvais identiants";
        welcome = "Bienvenue";
        youhave = "VOUS AVEZ";
        review_sg = "RAPPEL";
        review_pl = "RAPPELS";
        logout = "Déconnexion";
        testsession = "Session de test";
        stop = "Stop";
        order_single = "Choisir la bonne réponse";
        order_many = "Plusieurs réponses possibles";
        answer_text = "VALIDER";
        wait = "Un petit instant...";
        inshort = "Résumé";
        details = "En détail";
        home = "ACCUEIL";
        swip_indication = "Faites glisser l'écran <br> pour changer de question.";
        flag = "img/icon_en.jpg";
    }
    if (langue==="en"){
        login = "Log In";
        email = "Email";
        password = "Password";
        wrong_ids = ""; //A remplir
        welcome = "Welcome";
        youhave = "YOU HAVE";
        review_sg = "REVIEW";
        review_pl = "REVIEWS";
        logout = "Log out";
        testsession = "Test Session";
        stop = "Stop";
        order_single = "Choose the right answer";
        order_many = "Many possible answers";
        answer_text = "ANSWER";
        wait = "Wait a moment ...";
        inshort = "In short";
        details = "Details";
        home = "HOME";
        swip_indication = "Swip to change question.";
        flag = "img/icon_fr.jpg";
    }

    $$("#login").html(login);
    $$("#login_button").html(login);
    $$("#email_field").attr("placeholder", email);
    $$("#password_field").attr("placeholder", password);
    $$("#welcome").html(welcome + "<br> <span id='index-username'></span>");
    $$("#youhave").html(youhave);
    $$("#logout").html(logout);
    $$("#flag").attr("src", flag);
}

