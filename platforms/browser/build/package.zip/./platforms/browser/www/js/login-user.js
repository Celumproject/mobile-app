function loginUser(loginData){

    myApp.showPreloader(wait);

    loginData = { "pLogin" : "domoscio", "pPassword" : "domoscio"};

    $.ajax({
        method: "POST",
        url: "http://quiz-beta.xperteam.net/webservices/usermanager.asmx/userExists",
        data: loginData,
        dataType: "xml",
        crossDomain: true,
        async : false,
        complete: function(e){
            var doc = e.responseXML;
            var bool = doc.getElementsByTagName("boolean")[0].childNodes[0].nodeValue;
            if(bool === "true"){
                localStorage.setItem("loginData", loginData);

                //UserGetInformation : Enregistrer le prénom et le student_uid.
                $.ajax({
                    method: "POST",
                    url: "http://quiz-beta.xperteam.net/webservices/quizmanagerwebservice.asmx/UserGetInformation",
                    data: {"id" : loginData.pLogin, "idType" : "login" },
                    dataType: "xml",
                    crossDomain: true,
                    async : false,
                    complete: function(e){
                        var doc = e.responseXML;
                        localStorage.setItem("firstname", doc.getElementsByTagName("fname")[0].childNodes[0].nodeValue);
                        localStorage.setItem("name", doc.getElementsByTagName("lname")[0].childNodes[0].nodeValue);
                        localStorage.setItem("student_id", 2); //2 ou 11, dans l'exemple. Il faut trouver le bon champ.
                    }
                });

/*
                //Enregistrer le student_uid, device_id, token...
                console.log("device : " + JSON.stringify(device));
                console.log("registration ID : " + localStorage.getItem('registrationId'));
                // Envoi des informations du device pour le push engine.
*/

                var platform='';
                console.log("android ? " + myApp.device.android);
                console.log("ios ? " + myApp.device.ios);
                if (myApp.device.android){
                    platform="android";
                }
                else if (myApp.device.ios){
                    platform="ios";
                }

                var push_engine_data = {
                    "api_id" : localStorage.getItem("student_id"),
                    "device_type" : platform,
                    "device_id" : localStorage.getItem("registrationId"),
                }

                console.log(JSON.stringify(push_engine_data));

/*
                $.ajax({
                    method: "POST",
                    url: "http://push-engine.domoscio.com/instances/" + instance_id + "/users?token=" + token,
                    data: push_engine_data,
                    dataType: "json",
                    async : false,
                    complete: function(e){}
                });
*/

                actualiserPageAccueil();
                myApp.closeModal('.login-screen', true);

            } else {
                myApp.alert(wrong_ids, login);
            }
        }



    });
    myApp.hidePreloader();
}
