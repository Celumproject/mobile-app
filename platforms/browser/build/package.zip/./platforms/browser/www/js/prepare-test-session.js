function prepareTestSession(testSessionJson){
    var qtiFormat = testSessionJson.questestinterop._xmlns;
    var summary = "";
    var answeredInSession = 0;
    //var answeredQuestions = JSON.parse(localStorage.getItem("answeredQuestions"));
    var testSession

    localStorage.setItem("rightAnswers", 0);
    localStorage.setItem("wrongAnswers", 0);
    localStorage.setItem("summary", summary);

    if(qtiFormat == "http://www.imsglobal.org/xsd/ims_qtiasiv1p2"){
        testSession = testSessionJson.questestinterop.assessment.section.section;
        result = prepareFrom1_2(testSession);
    } else {
        testSession = testSessionJson.questestinterop;
        result = prepareFrom2(testSession);
    }

    localStorage.setItem("totalAnswers", result.questions.length);
    var questions = result.questions;
    var innerSlides = result.innerSlides;
    $$(".swiper-wrapper").append($$(innerSlides));

    var mySwiper = myApp.swiper('.swiper-container', {
        pagination: '.swiper-pagination',
        paginationHide: false,
        paginationClickable: true,
        passiveListeners: false,
    });

    $$('.question_form').on('click', function(e){
        var questionId = e.target.getAttribute('id').replace("btn-q_", "");
        var question = questions.find(x => x.uid == questionId);
        var qForm = myApp.formToData('#form_' + questionId);
        var qScore, outcome;

        if(question.type.toLowerCase() == "single"){
            qScore = question.correct([qForm['radio_' + question.uid].replace('/','')])
        } else {
            $.each(qForm['checkbox_' + question.uid], function(i, ui){
                qForm['checkbox_' + question.uid][i] = ui.replace('/','');
            });
            qScore = question.correct(qForm['checkbox_' + question.uid]);
        }

        //var date = sendResult(qScore, question.number);
        var date = "2018902229"

        var swip='';
        var swip_info='';
        if (question.number===1 && answeredInSession ===0 && localStorage.getItem("nb_reviews")!==1) {
            //var swip = '<img class="size-25 color-black swiping" src="img/swip_left.svg"></img>';
            //$$("#consigne_" + question.uid).html("<div class='color-blue'> " + swip_indication + "</div>");
            swip_info = "<div class='swip-information'><div class=''><i class='f7-icons swiping'>arrow_left_fill</i></div> <div>" + swip_indication + "</div><div class=''><i class='f7-icons swiping'>arrow_left_fill</i></div></div>";
        }

        if(qScore){
            outcome = "<i class='f7-icons color-green'>check_round_fill</i>";
            var total_right = localStorage.getItem("rightAnswers");
            $$(".swiper-pagination-bullet-active").css("background", "#4caf50");
            localStorage.setItem("rightAnswers", parseInt(total_right) + 1);
            summary += '<li class="item-content"><div class="item-media"><i class="f7-icons color-green">check_round_fill</i></div><div class="item-inner"><div class="item-title">' + question.title + '</div><div class="item-after">' + afficheDate(date) + '</div></div></li>';
        } else {
            outcome = "<i class='f7-icons color-red'>close_round_fill</i>";
            var total_wrong = localStorage.getItem("wrongAnswers");
            $$(".swiper-pagination-bullet-active").css("background", "#f44336");
            localStorage.setItem("wrongAnswers", parseInt(total_wrong) + 1);
            summary += '<li class="item-content"><div class="item-media"><i class="f7-icons color-red">close_round_fill</i></div><div class="item-inner"><div class="item-title">' + question.title + '</div><div class="item-after">' + afficheDate(date) + '</div></div></li>';
        }

        $$("#block_" + question.uid).html( swip_info + "<div class=''><h1><center>" + swip + outcome + swip + "</center></h1></div>");

        //answeredQuestions.push(question);
        //localStorage.setItem("answeredQuestions", JSON.stringify(answeredQuestions));
        localStorage.setItem("summary", summary);
        answeredInSession += 1;

        if(answeredInSession === questions.length){
            setTimeout(function(){
            mainView.router.loadPage("session_results.html");
            },1500);
        }
    });
}
