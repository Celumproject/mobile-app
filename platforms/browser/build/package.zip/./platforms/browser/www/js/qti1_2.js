function prepareFrom1_2(testSession){
    var questions = new Array;
    var innerSlides = "";

    $.each(testSession.item, function(i, e){
         var propositions = [];
         var qNum = parseInt(i) + 1;
         var qId = e._ident;
         var qType = e.presentation.response_lid._rcardinality;

         var questionText = htmlDecode(e.presentation.material.mattext);

         innerSlides += "<div class='swiper-slide'><div class='content-block-title color-blue'><center>Question " + qNum + "</center></div>";
         innerSlides += "<div><span>" + questionText + "</span></div>";

         innerSlides += '<iframe width="560" height="315" src="https://www.youtube.com/embed/Fl1GYTg4GmA" frameborder="0" allowfullscreen></iframe>';

         innerSlides += "<form class='list-block inset' id='form_" + qId + "'><ul>";

         if(qType == "Single"){
           innerSlides += "<li class='list-group-title'> " + order_single + " </li>";
         } else {
           innerSlides += "<li class='list-group-title'> " + order_many + " </li>";
         }

         $.each(e.presentation.response_lid.render_choice.response_label, function(j, p){
           var prop_id = p._ident;
           var prop_text = htmlDecode(p.material.mattext);

           propositions.push(new Proposition(prop_id, prop_text));

           if(qType == "Single"){
             innerSlides += "<li><label for='answer_" + qId + "_" + prop_id + "' class='label-radio item-content'>";
             innerSlides += "<input type='radio' name='radio_" + qId + "' id='answer_" + qId + "_" + prop_id + "' value=" + prop_id + "/><div class='item-media'><i class='icon icon-form-radio'></i></div><div class='item-inner' id='answer_content_" + qId + "_" + prop_id + "'><div class='item-title'>" + prop_text + "</div></div>";
             innerSlides += "</label></li>";
           } else {
             innerSlides += "<li><label for='answer_" + qId + "_" + prop_id + "' class='label-checkbox item-content'>";
             innerSlides += "<input type='checkbox' name='checkbox_" + qId + "' id='answer_" + qId + "_" + prop_id + "' value=" + prop_id + "/><div class='item-media'><i class='icon icon-form-checkbox'></i></div><div class='item-inner' id='answer_content_" + qId + "_" + prop_id + "'><div class='item-title'>" + prop_text + "</div></div>";
             innerSlides += "</label></li>";
           }

         });

         innerSlides += "</ul></form>";
         innerSlides += "<div id='block_" + qId + "' class='content-block'><div id='btn-q_" + qId + "' class='button ripple question_form'> " + answer_text + " </div></div>";
         innerSlides += "</div>";

         var qCorrect = [new Array(), new Array()];

         if(e.resprocessing.respcondition instanceof Array){
             $.each(e.resprocessing.respcondition, function(k, r){
                 // it's a qcm
                 console.log(r);
                 var varScore = r.conditionvar.varequal.__text;
                 if(r.setvar.__text == 100){
                    qCorrect[0].push(varScore);
                 } else {
                    qCorrect[1].push(varScore);
                 }
             });
         } else {
             // it's a multi select question
             $.each(e.resprocessing.respcondition.conditionvar.and.varequal, function(h, c){
               console.log(c);
               qCorrect[0].push(c.__text);
             });

             if(e.resprocessing.respcondition.conditionvar.and.not){
               $.each(e.resprocessing.respcondition.conditionvar.and.not.varequal, function(h1, c1){
                 console.log(c1);
                 qCorrect[1].push(c1.__text);
               });
            }

          }

         questions.push(new Question(qNum, qId, qType, questionText, propositions, qCorrect));
    });

    return {
        questions: questions,
        innerSlides: innerSlides
    };
}
